const DB_URL = "mongodb://localhost:27017/";

module.exports.DB_URL = DB_URL;